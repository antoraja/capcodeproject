sap.ui.define(
    ["sap/fe/core/AppComponent"],
    function (Component) {
        "use strict";

        return Component.extend("purchaseorderui.purchaseorderui.Component", {
            metadata: {
                manifest: "json"
            }
        });
    }
);